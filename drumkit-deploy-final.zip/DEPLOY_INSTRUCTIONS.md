# 🚀 Guia de Deploy - Drum Kit Funk BR Premium Edition

## 📦 Arquivos Inclusos

```
drumkit-deploy-completo.zip
├── dist/                    # BUILD COMPILADA PRONTA PARA PRODUÇÃO
│   └── public/
│       ├── index.html       # Arquivo principal
│       ├── assets/          # CSS e JS compilados
│       └── studio-setup.png # Imagem
├── client/                  # Código fonte React/TypeScript
├── package.json             # Dependências do projeto
├── vite.config.ts           # Configuração do Vite
├── tsconfig.json            # Configuração TypeScript
└── pnpm-lock.yaml          # Lock file das dependências
```

---

## 🌐 OPÇÃO 1: DEPLOY NO VERCEL (RECOMENDADO)

### Passo 1: Preparar o Projeto
```bash
# Extrair o ZIP
unzip drumkit-deploy-completo.zip
cd drumkit-premium-lp

# Instalar dependências
npm install
# ou
pnpm install
```

### Passo 2: Fazer Deploy
```bash
# Instalar Vercel CLI
npm i -g vercel

# Fazer login
vercel login

# Deploy
vercel --prod
```

### Passo 3: Configurar Domínio
1. Acesse: https://vercel.com/dashboard
2. Selecione seu projeto
3. Vá para "Settings" → "Domains"
4. Adicione seu domínio: `funkbrdrumkit.com`
5. Siga as instruções para apontar o DNS

### Resultado
- URL: `https://funkbrdrumkit.com`
- SSL automático ✅
- Deploy automático com git ✅
- Sem custo (plano gratuito) ✅

---

## 🌐 OPÇÃO 2: DEPLOY NO NETLIFY

### Passo 1: Preparar o Projeto
```bash
unzip drumkit-deploy-completo.zip
cd drumkit-premium-lp
npm install
```

### Passo 2: Build Local
```bash
npm run build
```

### Passo 3: Fazer Deploy
1. Acesse: https://app.netlify.com
2. Clique em "Add new site" → "Deploy manually"
3. Arraste a pasta `dist/public` para o upload
4. Ou conecte seu repositório GitHub

### Passo 4: Configurar Domínio
1. Vá para "Site settings" → "Domain management"
2. Clique em "Add custom domain"
3. Digite: `funkbrdrumkit.com`
4. Siga as instruções de DNS

### Resultado
- URL: `https://funkbrdrumkit.com`
- SSL automático ✅
- Sem custo (plano gratuito) ✅

---

## 🌐 OPÇÃO 3: DEPLOY NA HOSTGATOR

### Passo 1: Compilar o Projeto
```bash
unzip drumkit-deploy-completo.zip
cd drumkit-premium-lp
npm install
npm run build
```

### Passo 2: Preparar Arquivos
```bash
# Os arquivos compilados estão em:
dist/public/

# Você precisa fazer upload de:
# - dist/public/index.html
# - dist/public/assets/
# - dist/public/studio-setup.png
```

### Passo 3: Fazer Upload na HostGator
1. Acesse o Gerenciador de Arquivos da HostGator
2. Navegue até: `/public_html`
3. **IMPORTANTE**: Se tiver WordPress, faça backup primeiro!
4. Faça upload dos arquivos de `dist/public/`:
   - `index.html` (arquivo principal)
   - Pasta `assets/` (CSS e JS compilados)
   - `studio-setup.png` (imagem)

### Passo 4: Configurar .htaccess (IMPORTANTE!)
Crie um arquivo `.htaccess` em `/public_html` com o conteúdo:

```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
```

### Passo 5: Resultado
- URL: `https://funkbrdrumkit.com`
- Site funcionando ✅

---

## 📋 ESTRUTURA DO BUILD

```
dist/public/
├── index.html                          # 367 KB
├── assets/
│   ├── index-2xnpmCJb.css             # 144 KB (CSS compilado)
│   └── index-CFe-skE8.js              # 753 KB (JS compilado)
└── studio-setup.png                    # 373 KB (Imagem)

Total: ~1.7 MB
```

---

## 🔧 VARIÁVEIS DE AMBIENTE

Se precisar de variáveis de ambiente, crie um arquivo `.env`:

```env
VITE_API_URL=https://api.seu-dominio.com
VITE_APP_NAME=Drum Kit Funk BR
```

Depois, recompile:
```bash
npm run build
```

---

## ✅ CHECKLIST PRÉ-DEPLOY

- [ ] Extraiu o ZIP
- [ ] Instalou dependências (`npm install`)
- [ ] Compilou o projeto (`npm run build`)
- [ ] Verificou a pasta `dist/public/`
- [ ] Testou localmente (`npm run dev`)
- [ ] Fez backup (se necessário)
- [ ] Escolheu a plataforma de deploy
- [ ] Configurou o domínio
- [ ] Testou o site em produção

---

## 🚨 TROUBLESHOOTING

### Problema: Página branca após deploy
**Solução**: Limpe o cache do navegador (Ctrl+Shift+Del)

### Problema: CSS/JS não carregam
**Solução**: Verifique se os arquivos estão em `assets/`

### Problema: Rotas não funcionam
**Solução**: Configure o `.htaccess` (HostGator) ou `vercel.json` (Vercel)

### Problema: Imagens não aparecem
**Solução**: Verifique o caminho das imagens em `dist/public/`

---

## 📞 SUPORTE

Se tiver dúvidas:
1. Verifique se os arquivos estão em `dist/public/`
2. Teste localmente: `npm run dev`
3. Verifique o console do navegador (F12)
4. Verifique os logs da plataforma de deploy

---

## 🎉 PRONTO!

Seu site estará online em minutos! 🚀

**Próximos passos:**
1. Integrar links do Kiwify nos botões de compra
2. Adicionar Google Analytics
3. Configurar SEO (meta tags, sitemap)
4. Divulgar nas redes sociais

---

**Versão**: 1.0.0
**Data**: 17/05/2026
**Status**: ✅ Pronto para Deploy
